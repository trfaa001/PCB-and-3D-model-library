G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.2*
G04 #@! TF.CreationDate,2025-10-04T01:38:54+02:00*
G04 #@! TF.ProjectId,HCNR200 breakout,48434e52-3230-4302-9062-7265616b6f75,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.2) date 2025-10-04 01:38:54*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10R,1.700000X1.700000*%
%ADD11C,1.700000*%
%ADD12RoundRect,0.102000X-1.145000X-0.650000X1.145000X-0.650000X1.145000X0.650000X-1.145000X0.650000X0*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J2*
X151500000Y-63500000D03*
D11*
X151500000Y-66040000D03*
X151500000Y-68580000D03*
X151500000Y-71120000D03*
G04 #@! TD*
D10*
G04 #@! TO.C,J1*
X132500000Y-63500000D03*
D11*
X132500000Y-66040000D03*
X132500000Y-68580000D03*
X132500000Y-71120000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,J3*
X136230000Y-63380000D03*
X136230000Y-65920000D03*
X136230000Y-68460000D03*
X136230000Y-71000000D03*
X147500000Y-71000000D03*
X147500000Y-68460000D03*
X147500000Y-65920000D03*
X147500000Y-63380000D03*
G04 #@! TD*
M02*
